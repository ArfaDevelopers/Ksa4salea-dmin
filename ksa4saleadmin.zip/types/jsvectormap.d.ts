declare module 'jsvectormap' {
    // You can add more specific type definitions if needed
    const JsVectorMap: any;
    export default JsVectorMap;
  }